CREATE PROCEDURE CreateOperator
    @cellphone NVARCHAR(20),
    @email NVARCHAR(255)
AS
BEGIN
    INSERT INTO Operator (cellphone, email)
    VALUES (@cellphone, @email);
END;

GO

CREATE PROCEDURE ReadOperator
    @email NVARCHAR(255)
AS
BEGIN
    SELECT * FROM Operator
    WHERE email = @email;
END;

GO

CREATE PROCEDURE DeleteOperator
    @email NVARCHAR(255)
AS
BEGIN
    DELETE FROM Operator
    WHERE email = @email;
END;

